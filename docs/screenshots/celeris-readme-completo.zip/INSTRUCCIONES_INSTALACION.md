# 📦 GUÍA DE INSTALACIÓN - CELERIS README CON SCREENSHOTS

## 📋 Contenido del Paquete

Tienes 3 archivos principales + carpeta de imágenes:

```
outputs/
├── CELERIS_README.md          # README completo con imágenes integradas
├── .env.example                # Template de configuración (SIN datos sensibles)
├── .gitignore                  # Protección completa de archivos sensibles
└── docs/
    └── screenshots/            # 9 capturas optimizadas
        ├── 01-login-modo-oscuro.png
        ├── 02-login-modo-claro.png
        ├── 03-dashboard-admin.png
        ├── 04-gestion-usuarios.png
        ├── 05-lista-solicitudes.png
        ├── 06-panel-chofer.png
        ├── 07-iniciar-servicio.png
        ├── 08-sistema-comentarios.png
        └── 09-finalizar-servicio-gastos.png
```

---

## 🚀 INSTALACIÓN PASO A PASO

### Paso 1: Preparar tu repositorio local

```bash
# Navegar a tu repositorio de Celeris
cd /ruta/a/tu/proyecto/Celeris

# Verificar que estás en la rama correcta
git branch
# Si no estás en 'main', cambiar:
git checkout main
```

### Paso 2: Copiar los archivos descargados

```bash
# Opción A: Si descargaste todo en una carpeta llamada "outputs"
cd /ruta/donde/descargaste/outputs

# Copiar README
cp CELERIS_README.md /ruta/a/tu/proyecto/Celeris/README.md

# Copiar archivos de configuración
cp .env.example /ruta/a/tu/proyecto/Celeris/server/.env.example
cp .gitignore /ruta/a/tu/proyecto/Celeris/.gitignore

# Copiar carpeta de screenshots
cp -r docs/ /ruta/a/tu/proyecto/Celeris/
```

### Paso 3: Verificar la estructura

```bash
# En tu proyecto Celeris, verificar que quedó así:
cd /ruta/a/tu/proyecto/Celeris

tree -L 3
# O simplemente listar:
ls -la

# Deberías ver:
# Celeris/
# ├── README.md                    ✅ (nuevo)
# ├── .gitignore                   ✅ (nuevo/actualizado)
# ├── server/
# │   └── .env.example             ✅ (nuevo)
# ├── docs/
# │   └── screenshots/             ✅ (nueva carpeta con 9 imágenes)
# └── ... (resto de archivos)
```

### Paso 4: Verificar que .env NO esté en el repo

```bash
# CRÍTICO: Verificar que .env no esté siendo rastreado
git status

# Si ves .env en la lista, eliminarlo del tracking:
git rm --cached .env
git rm --cached server/.env

# Agregar .gitignore primero para proteger archivos sensibles
git add .gitignore
git commit -m "security: agregar .gitignore para proteger datos sensibles"
```

### Paso 5: Agregar los nuevos archivos

```bash
# Agregar README y archivos de configuración
git add README.md
git add server/.env.example

# Agregar carpeta de screenshots
git add docs/screenshots/

# Verificar qué se va a subir
git status

# Deberías ver SOLO estos archivos (NO .env):
# ✅ README.md
# ✅ .gitignore
# ✅ server/.env.example
# ✅ docs/screenshots/ (9 imágenes)
```

### Paso 6: Hacer commit y push

```bash
# Commit con mensaje descriptivo
git commit -m "docs: README profesional con capturas de pantalla y seguridad mejorada

- Agregar README completo con documentación profesional
- Incluir 9 capturas de pantalla optimizadas
- Agregar .env.example para configuración segura
- Actualizar .gitignore para protección de datos sensibles
- Organizar imágenes en docs/screenshots/
"

# Push al repositorio
git push origin main
```

### Paso 7: Verificar en GitHub

```bash
# Abrir en el navegador:
https://github.com/Alexey-Ortega/Celeris

# Verificar que:
# ✅ El README se ve correctamente con las imágenes
# ✅ Las imágenes cargan sin problemas
# ✅ El .env NO aparece en el repositorio
# ✅ Los archivos de ejemplo (.env.example) SÍ están
```

---

## 🔍 CHECKLIST DE SEGURIDAD

Antes de hacer push, verificar:

- [ ] ✅ `.env` está en `.gitignore`
- [ ] ✅ `.env` NO aparece en `git status`
- [ ] ✅ Las imágenes NO contienen información sensible visible
- [ ] ✅ El README usa placeholders para credenciales
- [ ] ✅ No hay URLs de producción reales en el código
- [ ] ✅ Los nombres de usuarios en screenshots son de prueba

---

## 📊 TAMAÑO DE ARCHIVOS

```
Total de imágenes: ~175 KB (muy optimizado ✅)

Desglose:
- 01-login-modo-oscuro.png:          15 KB
- 02-login-modo-claro.png:           15 KB
- 03-dashboard-admin.png:            25 KB
- 04-gestion-usuarios.png:           31 KB
- 05-lista-solicitudes.png:          34 KB
- 06-panel-chofer.png:               26 KB
- 07-iniciar-servicio.png:           13 KB
- 08-sistema-comentarios.png:         8 KB
- 09-finalizar-servicio-gastos.png:   9 KB
```

**Excelente tamaño para GitHub** - No afectará la velocidad del repositorio.

---

## 🎨 CÓMO SE VEN LAS IMÁGENES EN EL README

El README está organizado en 3 secciones colapsables:

### 1. Sección Principal (siempre visible)
- Comparación Login Modo Oscuro vs Claro (tabla lado a lado)
- Dashboard Administrativo (imagen grande centrada)

### 2. Sección Colapsable: "Gestión de Usuarios y Solicitudes"
- Gestión de usuarios
- Lista de solicitudes

### 3. Sección Colapsable: "Panel del Chofer"
- Vista principal del chofer
- Inicio de servicio
- Sistema de comentarios
- Finalización con gastos

Esto mantiene el README limpio y permite al lector explorar según su interés.

---

## ⚠️ PROBLEMAS COMUNES Y SOLUCIONES

### Problema 1: Las imágenes no cargan en GitHub

**Solución:**
```bash
# Verificar que la ruta es correcta:
# En el README: docs/screenshots/01-login-modo-oscuro.png
# En el repo: debe existir esa carpeta y archivo

# Verificar con:
ls -la docs/screenshots/
```

### Problema 2: Git dice que .env está modificado

**Solución:**
```bash
# Agregar .env al .gitignore
echo ".env" >> .gitignore
echo "server/.env" >> .gitignore

# Remover del tracking si ya estaba
git rm --cached .env
git rm --cached server/.env

# Commit
git add .gitignore
git commit -m "security: excluir .env del repositorio"
```

### Problema 3: Las imágenes son muy grandes

**Solución:**
Ya están optimizadas (175KB total), pero si quieres reducirlas más:
```bash
# Instalar imagemagick si no lo tienes
# sudo apt install imagemagick  # Linux
# brew install imagemagick      # macOS

# Optimizar todas las imágenes
for img in docs/screenshots/*.png; do
    convert "$img" -quality 85 -resize 1920x1080\> "$img"
done
```

---

## 🎯 RESULTADO FINAL

Después de seguir estos pasos, tu repositorio de Celeris tendrá:

✅ **README profesional** con badges, tabla de contenidos y documentación completa
✅ **9 capturas de pantalla** mostrando todas las funcionalidades clave
✅ **Seguridad reforzada** con .gitignore y .env.example
✅ **Estructura organizada** con carpeta docs/screenshots/
✅ **Sin datos sensibles** expuestos públicamente

---

## 📞 SOPORTE

Si tienes problemas:
1. Verifica que seguiste todos los pasos en orden
2. Revisa la sección de problemas comunes arriba
3. Verifica el checklist de seguridad
4. Si el README no se ve bien en GitHub, espera 1-2 minutos (GitHub cachea)

---

## 🚀 PRÓXIMOS PASOS (OPCIONAL)

Después de tener el README funcionando:

1. **Agregar más documentación:**
   ```bash
   # Crear docs adicionales
   touch docs/API.md
   touch docs/DATABASE.md
   touch docs/DEPLOYMENT.md
   ```

2. **Configurar GitHub Pages** (si quieres documentación web)

3. **Agregar badges de CI/CD** cuando implementes tests

4. **Crear CHANGELOG.md** para versiones futuras

---

¡Listo! Con esto tu repositorio Celeris quedará profesional y seguro. 🎉
